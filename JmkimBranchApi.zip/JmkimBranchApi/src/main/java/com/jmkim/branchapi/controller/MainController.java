package com.jmkim.branchapi.controller;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jmkim.branchapi.service.BranchService;
import com.jmkim.branchapi.service.MemberService;

@RestController
@RequestMapping(value="/")
public class MainController {
	@Autowired
	MemberService memberService;
	
	@Autowired
	BranchService branchService;
	
	// 연결 확인용
	@RequestMapping(value="/")
	public ResponseEntity<HashMap<String, Object>> index() {
		HashMap<String, Object> indexInfo = new HashMap<String, Object>();
		indexInfo.put("name", "김진명");
		indexInfo.put("position", "증권 IT 개발자");
		indexInfo.put("conn", "OK");
		return new ResponseEntity<>(indexInfo, HttpStatus.OK);
	}
	
	/* 1.	2018년, 2019년 각 연도별 합계 금액이 가장 많은 고객을 추출하는 API 개발.
	    (단, 취소여부가 ‘Y’ 거래는 취소된 거래임, 합계 금액은 거래금액에서 수수료를 차감한 금액임) */
	@RequestMapping(value="test1",  method=RequestMethod.GET)
	public ResponseEntity<List<HashMap<String, Object>>> test1() throws Exception{
		List<HashMap<String, Object>> memInfo = memberService.selMaxAmtMemberByYear(); // 연도별 고객 거래금액 리스트
		return new ResponseEntity<>(memInfo, HttpStatus.OK);
	}
	
	/* 2.	2018년 또는 2019년에 거래가 없는 고객을 추출하는 API 개발.
        (취소여부가 ‘Y’ 거래는 취소된 거래임) */
	@RequestMapping(value="test2",  method=RequestMethod.GET)
	public ResponseEntity<List<HashMap<String, Object>>>  test2() throws Exception{
		LinkedList<HashMap<String, Object>> noExMemList = memberService.selNoExchangeMember(); // 미거래 고객 리스트
		return new ResponseEntity<>(noExMemList, HttpStatus.OK);
	}

	/* 3.	연도별 관리점별 거래금액 합계를 구하고 합계금액이 큰 순서로 출력하는 API 개발.
	    ( 취소여부가 ‘Y’ 거래는 취소된 거래임) */
	@RequestMapping(value="test3",  method=RequestMethod.GET)
	public ResponseEntity<LinkedList<HashMap<String, Object>>> test3() throws Exception{
		LinkedList<HashMap<String, Object>> brnchList = branchService.selBrnchAmtByYearDescAmt(); // 연도별 총 거래금액별 지점 거래금액 리스트
		return new ResponseEntity<>(brnchList, HttpStatus.OK);
	}
	
	/* 4.	분당점과 판교점을 통폐합하여 판교점으로 관리점 이관을 하였습니다. 
	     지점명을 입력하면 해당지점의 거래금액 합계를 출력하는 API 개발
	    ( 취소여부가 ‘Y’ 거래는 취소된 거래임)	 */
	@RequestMapping(value="test4",  method=RequestMethod.GET)
	public ResponseEntity<HashMap<String, Object>> test4(@RequestParam String brName) throws Exception{
		HashMap<String, Object> brnchCdInfo = branchService.selBrnchTTLBrCd(brName); // 지점코드 + 통폐합 지점 코드 정보
		HashMap<String, Object> errResult = new HashMap<String, Object>(); // 에러 메세지
		if(brnchCdInfo== null) {
			errResult.put("code", "404");
			errResult.put("메세지", "br code not found error");
			return new ResponseEntity<>(errResult, HttpStatus.NOT_FOUND);
		}else {
			String ttlBrnchCd = brnchCdInfo.get("ttlBrCode").toString();
			String[] ttlBrCdArr = ttlBrnchCd.split(",");
			brnchCdInfo.put("cdarr", ttlBrCdArr); 
			return new ResponseEntity<>(branchService.selBrnchAmt(brnchCdInfo), HttpStatus.OK); // 지점별 총 거래금액 정보
		}
	}
}
