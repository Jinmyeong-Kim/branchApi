package com.jmkim.branchapi.serviceImpl;

import java.util.HashMap;
import java.util.LinkedList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jmkim.branchapi.dao.BranchMapper;
import com.jmkim.branchapi.service.BranchService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BranchServiceImpl implements BranchService {
	
	@Autowired
	BranchMapper branchMapper;
	
	@SuppressWarnings("unchecked")
	@Override
	public LinkedList<HashMap<String, Object>> selBrnchAmtByYearDescAmt() throws Exception{
		LinkedList<HashMap<String, Object>> brnchAmtList = branchMapper.selBrnchAmtByYearDescAmt(); // 연도별, 거래금액별 지점 정보 
		LinkedList<HashMap<String, Object>> brnchList = new LinkedList<HashMap<String, Object>>();
		
		if(brnchAmtList.size() > 0) {
			String yearStr = brnchAmtList.get(0).get("yearList").toString(); // 조회 연도별 정보
			String[] yearArr = yearStr.split(",");
			
			for(String y : yearArr) {
				LinkedList<HashMap<String, Object>> removedYearObj = new LinkedList<HashMap<String, Object>>(); // year 없는 데이터
				HashMap<String, Object> yearData = new HashMap<>();
				for(HashMap<String, Object> b : brnchAmtList) {
					HashMap<String, Object> btmp = (HashMap<String, Object>) b.clone();
					if(btmp.get("year").equals(y)) {
						btmp.remove("year");
						btmp.remove("yearList");
						removedYearObj.add(btmp);
					}
				}
				yearData.put("year", y);
				yearData.put("dataList", removedYearObj);
				brnchList.add(yearData);
			}
		}
		return brnchList;
	}

	@Override
	public HashMap<String, Object> selBrnchTTLBrCd(String brName) throws Exception{
		return branchMapper.selBrnchTTLBrCd(brName);
	}

	@Override
	public HashMap<String, Object> selBrnchAmt(HashMap<String, Object> brnchInfo) throws Exception{
		return branchMapper.selBrnchAmt(brnchInfo);
	}

}
