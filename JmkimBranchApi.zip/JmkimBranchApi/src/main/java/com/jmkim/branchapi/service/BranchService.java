package com.jmkim.branchapi.service;

import java.util.HashMap;
import java.util.LinkedList;

public interface BranchService {
	public LinkedList<HashMap<String, Object>> selBrnchAmtByYearDescAmt() throws Exception; // 연도별 총 거래금액별 지점 거래금액 리스트
	public HashMap<String, Object> selBrnchTTLBrCd(String brName) throws Exception; // 지점코드 + 통폐합 지점 코드 정보
	public HashMap<String, Object> selBrnchAmt(HashMap<String, Object> brnchInfo) throws Exception; // 지점별 총 거래금액 정보
}
